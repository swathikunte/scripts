package com.cigniti.foodApp.service;

import com.cigniti.foodApp.entity.Genie;

public interface GenieService {
    //List<Genie> findAll();

    void save(Genie genie);

    /*Genie findByGenieId(int id);

    void deleteByGenieId(int id);*/
}