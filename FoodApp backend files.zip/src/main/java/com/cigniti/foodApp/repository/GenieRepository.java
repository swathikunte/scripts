
package com.cigniti.foodApp.repository;

import com.cigniti.foodApp.entity.Genie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GenieRepository extends JpaRepository<Genie, Integer> {
}