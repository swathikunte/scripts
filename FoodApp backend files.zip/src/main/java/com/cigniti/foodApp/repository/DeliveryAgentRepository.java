package com.cigniti.foodApp.repository;

import com.cigniti.foodApp.entity.DeliveryAgent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliveryAgentRepository extends JpaRepository<DeliveryAgent,Integer> {

}
